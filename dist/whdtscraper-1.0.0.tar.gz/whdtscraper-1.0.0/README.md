# wikimedia-history-dump-tsv-screaper
A project that scrapes the wikimedia history dump site in order to retrieve the available tsv to download
