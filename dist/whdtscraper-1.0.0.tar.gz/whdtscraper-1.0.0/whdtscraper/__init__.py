from whdtscraper.whdtscraper import fetch_latest_version, fetch_versions, fetch_wikies, fetch_dumps, WIKI_URL
